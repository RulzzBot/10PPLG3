const sisi1 = 8;
const sisi2 = 12;
const tinggi = 5;
const rumus = 0.5;

export { sisi1, sisi2, tinggi, rumus };